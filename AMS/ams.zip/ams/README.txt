A Pen created at CodePen.io. You can find this one at http://codepen.io/DRiNVAD3R/pen/zzaybp.

 My shot on a modern responsive online Resume/Portfolio